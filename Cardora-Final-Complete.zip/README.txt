CARDORA FINAL LOCAL SETUP

1. BACK UP your existing cardora-easy-version folder.
2. Copy these files into the folder:
   index.html
   app.js
   server.js
   admin.html
   .env.example
3. Keep your existing .env file. Do NOT overwrite it with .env.example.
4. In CMD, inside cardora-easy-version:
   npm install nodemailer
5. Start:
   node server.js
6. Open:
   http://localhost:3000

ADMIN:
   http://localhost:3000/admin
   Use ADMIN_EMAIL and ADMIN_PASSWORD from .env.

EMAIL:
   If EMAIL_HOST / EMAIL_USER / EMAIL_PASS are blank, verification codes print in CMD.
   To send real email, configure SMTP in your local .env. Never put SMTP passwords in index.html.

FLOW:
   Sign up -> email verification -> sign in
   Seller -> submit voucher -> Submission ID -> admin review -> 78% payout amount
   Buyer -> order -> crypto address/network -> TXID -> admin verifies -> admin assigns approved voucher -> admin delivers -> buyer sees code

CRYPTO:
   USDT TRC-20
   USDC Solana
   SOL Solana
   BTC Bitcoin
   ETH Ethereum

IMPORTANT:
   The server does not automatically declare a TXID valid. Admin verification is required until a real blockchain verification provider is connected.
